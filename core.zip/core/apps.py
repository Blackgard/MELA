from django.apps import AppConfig


class CoreConfig(AppConfig):
    name = 'MELA'
    verbose_name = "movement of e-learning aids"
